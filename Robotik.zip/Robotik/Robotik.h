/*
  Robotik.h - Library for a school roboticsshield.
  Created by Emil Altmann, June 27, 2021.
  Released into the public domain.
*/
#ifndef Robotik_h
#define Robotik_h

#include "Arduino.h"
#include <avr/io.h>

#define INT_D 2  //INT0
#define INT_E 3  //INT1

#define LED_1 7
#define LED_2 4

#define PWM_A 6  //OC0A
#define PWM_B 5  //OC0B
#define PWM_C 11 //OC2A
#define PWM_D 9  //OC1A
#define PWM_E 10 //OC1B

#define ULTRA_REC_A 13
#define ULTRA_REC_B 8
#define ULTRA_TRIG 12

#define INPUT_1 A0
#define INPUT_2 A1
#define INPUT_3 A2
#define BUTTON A3


void InitialisiereRobotik();

void rotiere_A_zu_Position(int Position);
void rotiere_B_zu_Position(int Position);
void rotiere_C_zu_Position(int Position);

void rotiere_D(int Geschwindigkeit);
void rotiere_E(int Geschwindigkeit);

void stoppe_D();
void stoppe_E();

bool ist_1_gedrueckt();
bool ist_2_gedrueckt();
bool ist_3_gedrueckt();
bool ist_Knopf_gedrueckt();

int distanz_A();
int distanz_B();

void schalte_LED1_an();
void schalte_LED1_aus();
void schalte_LED2_an();
void schalte_LED2_aus();

void warte(double Sekunden);
#endif

/*
  Robotik.h - Library for a school roboticsshield.
  Created by Emil Altmann, June 27, 2021.
  Released into the public domain.
*/
#ifndef Robotik_h
#define Robotik_h

#include "Arduino.h"
#include "Servo.h"

void decreaseD();
void decreaseE();
void InitialisiereRobotik();
void rotiere_A_zu_Position(int Position);
void rotiere_B_zu_Position(int Position);
void rotiere_C_zu_Position(int Position);
void rotiere_D_fuer_n_Pulse(int Pulse);
void rotiere_E_fuer_n_Pulse(int Pulse);
void rotiere_D_fuer_n_Pulse(int Pulse,int Geschwindigkeit);
void rotiere_E_fuer_n_Pulse(int Pulse,int Geschwindigkeit);
void rotiere_D(int Geschwindigkeit);
void rotiere_E(int Geschwindigkeit);
void stoppe_D();
void stoppe_E();
bool ist_1_gedrueckt();
bool ist_2_gedrueckt();
bool ist_3_gedrueckt();
bool ist_Knopf_gedrueckt();
int distanz_A();
int distanz_B();
void schalte_LED1_an();
void schalte_LED1_aus();
void schalte_LED2_an();
void schalte_LED2_aus();
void warte(double Sekunden);
bool rotiert_D();
bool rotiert_E();
// volatile bool turningD;
// volatile bool turningE;
// void schreibe(void* Ausgabe);
// static Servo servoA;
// static Servo servoB;
// static Servo servoC;
// static Servo servoD;
// static Servo servoE;
// static volatile int stepsD;
// static volatile int stepsE;
// static const unsigned long debounceDelay;
// static volatile unsigned long lastDebounceTimeD;
// static volatile unsigned long lastDebounceTimeE;


#endif
/*
  Robotik.cpp - Library for a school roboticsshield.
  Created by Emil Altmann, June 27, 2021.
  Released into the public domain.
*/

#include "Arduino.h"
#include "Robotik.h"
#include "Servo.h"


Servo servoA;
Servo servoB;
Servo servoC;
Servo servoD;
Servo servoE;
volatile int stepsD = 0;
volatile int stepsE = 0;
const unsigned long debounceDelay = 50;
volatile unsigned long lastDebounceTimeD = millis();
volatile unsigned long lastDebounceTimeE = millis();
volatile bool turningD = false;
volatile bool turningE = false;


void InitialisiereRobotik() {

  //~ servoA.attach(6);
  //~ servoB.attach(7);
  //~ servoC.attach(8);
  //~ servoD.attach(9);
  //~ servoE.attach(10);

  //~ servoA.write(0);
  //~ servoB.write(0);
  //~ servoC.write(0);
  //~ servoD.write(90);
  //~ servoE.write(90);
  
  //~ pinMode(2,INPUT_PULLUP);
  //~ pinMode(3,INPUT_PULLUP);

  //~ const byte interruptPinD = 2;
  //~ pinMode(interruptPinD, INPUT);
  //~ attachInterrupt(digitalPinToInterrupt(interruptPinD), decreaseD, CHANGE);


  //~ const byte interruptPinE = 3;
  //~ pinMode(interruptPinE, INPUT);
  //~ attachInterrupt(digitalPinToInterrupt(interruptPinE), decreaseE, CHANGE);


  pinMode(A0, INPUT_PULLUP);
  pinMode(A1, INPUT_PULLUP);
  pinMode(A2, INPUT_PULLUP);
  pinMode(0, INPUT_PULLUP);

  pinMode(13,INPUT);
  pinMode(12,OUTPUT);
  pinMode(11,INPUT);

  pinMode(5,OUTPUT);

  Serial.begin(9600);
}
void decreaseD() {
  //~ if ((millis() - lastDebounceTimeD) > debounceDelay) {
  //~ stepsD--;
  //~ if (stepsD<1) {
    //~ turningD= false;
    //~ servoD.write(90);
  //~ }
  //~ lastDebounceTimeD = millis();
  //~ }
}
void decreaseE() {
  //~ if ((millis() - lastDebounceTimeE) > debounceDelay) {
  //~ stepsE--;
  //~ // Serial.println(stepsE);
  //~ if (stepsE<1) {
    //~ turningE = false;
    //~ servoE.write(90);
  //~ }
  //~ lastDebounceTimeE = millis();
  //~ }
}
void rotiere_A_zu_Position(int Position){
    if (!servoA.attached()) {
        servoA.attach(6);
        }
  if (Position >270) {
    Position = 270;
  } else if (Position <0) {
    Position = 0;
  }
  Position = (double)Position * 180 / 270 ;
  Serial.println(Position);
  servoA.write(Position);
}
void rotiere_B_zu_Position(int Position){
        if (!servoB.attached()) {
        servoB.attach(7);
        }
  if (Position >270) {
    Position = 270;
  } else if (Position <0) {
    Position = 0;
  }
  Position = (double)Position * 180 / 270 ;
  servoB.write(Position);
}
void rotiere_C_zu_Position(int Position){
        if (!servoC.attached()) {
        servoC.attach(8);
        }
  if (Position >270) {
    Position = 270;
  } else if (Position <0) {
    Position = 0;
  }
  Position = (double)Position * 180 / 270 ;
  servoC.write(Position);
}
void rotiere_D_fuer_n_Pulse(int Pulse){
  //~ turningD = true;
  //~ if (Pulse >0) {
    //~ stepsD = Pulse;
    //~ servoD.write(180);
  //~ } else if (Pulse <0) {
    //~ stepsD = -Pulse;
    //~ servoD.write(0);
  //~ }
}
void rotiere_E_fuer_n_Pulse(int Pulse){
  //~ turningE = true;
  //~ if (Pulse >0) {
    //~ stepsE = Pulse;
    //~ servoE.write(180);
  //~ } else if (Pulse <0) {
    //~ stepsE = -Pulse;
    //~ servoE.write(0);
  //~ }
}
void rotiere_D_fuer_n_Pulse(int Pulse,int Geschwindigkeit){
  //~ turningD = true;
  //~ if (Geschwindigkeit <0) {
    //~ Geschwindigkeit = 0;
  //~ } else if (Geschwindigkeit > 100) {
    //~ Geschwindigkeit = 100;
  //~ }
  //~ Geschwindigkeit = ((double)Geschwindigkeit) * 0.9;
  //~ if (Pulse >0) {
    //~ stepsD = Pulse;
    //~ servoD.write(90+Geschwindigkeit);
  //~ } else if (Pulse <0) {
    //~ stepsD = -Pulse;
    //~ servoD.write(90-Geschwindigkeit);
  //~ }
}
void rotiere_E_fuer_n_Pulse(int Pulse,int Geschwindigkeit){
  //~ turningE = true;
  //~ if (Geschwindigkeit <0) {
    //~ Geschwindigkeit = 0;
  //~ } else if (Geschwindigkeit > 100) {
    //~ Geschwindigkeit = 100;
  //~ }
  //~ Geschwindigkeit = ((double)Geschwindigkeit) * 0.9;
  //~ if (Pulse >0) {
    //~ stepsE = Pulse;
    //~ servoE.write(90+Geschwindigkeit);
  //~ } else if (Pulse <0) {
    //~ stepsE = -Pulse;
    //~ servoE.write(90-Geschwindigkeit);
  //~ }
}
void rotiere_D(int Geschwindigkeit){
        if (!servoD.attached()) {
        servoD.attach(9);
        }
  if (Geschwindigkeit>100) {
    Geschwindigkeit = 100;
  } else if (Geschwindigkeit<-100) {
    Geschwindigkeit = -100;
  }
  servoD.write(90+(90*(double)Geschwindigkeit)/100);
}

void rotiere_E(int Geschwindigkeit){
        if (!servoE.attached()) {
        servoE.attach(10);
        }
  if (Geschwindigkeit>100) {
    Geschwindigkeit = 100;
  } else if (Geschwindigkeit<-100) {
    Geschwindigkeit = -100;
  }
  servoE.write(90+(90*(double)Geschwindigkeit)/100);
}
bool rotiert_E() {
  return turningE;
}
void stoppe_D(){
    if (servoD.attached()) {
        servoD.write(90);
    servoD.detach();
    }
}
void stoppe_E(){
   if (servoE.attached()) {
    servoE.write(90);
    servoE.detach();
    }
}
bool ist_1_gedrueckt(){
  return analogRead(A0) < 512;
}
bool ist_2_gedrueckt(){
  return analogRead(A1) < 512;
}
bool ist_3_gedrueckt(){
  return analogRead(A2) < 512;
}
bool ist_Knopf_gedrueckt(){
  return digitalRead(A3) == LOW;
}
int distanz_A(){
  digitalWrite(12,LOW);
  delayMicroseconds(2);
  digitalWrite(12, HIGH);
  delayMicroseconds(10);
  digitalWrite(12, LOW);
  unsigned long duration = pulseIn(13, HIGH);
  int distance = (int) duration * 0.034 / 2;
  if (distance <=200){
    return distance;
  }
  return 200;
}
int distanz_B(){
  digitalWrite(12,LOW);
  delayMicroseconds(2);
  digitalWrite(12, HIGH);
  delayMicroseconds(10);
  digitalWrite(12, LOW);
  unsigned long duration = pulseIn(11, HIGH);
  int distance = (int) duration * 0.034 / 2;
  if (distance <=200){
    return distance;
  }
  return 200;
}
void schalte_LED1_an() {
  digitalWrite(5,HIGH);
}
void schalte_LED1_aus() {
  digitalWrite(5,LOW);
}
void schalte_LED2_an() {
  digitalWrite(4,HIGH);
}
void schalte_LED2_aus() {
  digitalWrite(4,LOW);
}
void warte(double Sekunden){
  delay((int) (Sekunden * 1000));
}

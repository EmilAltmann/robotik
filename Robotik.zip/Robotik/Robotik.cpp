/*
  Robotik.cpp - Library for a school roboticsshield.
  Created by Emil Altmann, June 27, 2021.
  Released into the public domain.
*/

#include "Robotik.h"

volatile bool turningD = false;
volatile bool turningE = false;


void InitialisiereRobotik() {
    
    //inputs
    pinMode(INPUT_1, INPUT_PULLUP);
    pinMode(INPUT_2, INPUT_PULLUP);
    pinMode(INPUT_3, INPUT_PULLUP);
    pinMode(BUTTON, INPUT_PULLUP);

    //ultrasonic
    pinMode(ULTRA_TRIG,OUTPUT);
    pinMode(ULTRA_REC_A,INPUT);
    pinMode(ULTRA_REC_B,INPUT);

    //motors
    pinMode(PWM_A,OUTPUT);
    pinMode(PWM_B,OUTPUT);
    pinMode(PWM_C,OUTPUT);
    pinMode(PWM_D,OUTPUT);
    pinMode(PWM_E,OUTPUT);
    
    //LEDs
    pinMode(LED_1,OUTPUT);
    pinMode(LED_2,OUTPUT);

    Serial.begin(9600);
    
    // set Timer0 OC0A/B
    TCCR0A = (1 << WGM01) | (1 << WGM00); //Fast PWM
    TCCR0B = (1 << CS02) | (1 << CS00); //PRESCALE clk/1024
    
    // set Timer1 OC1A/B
    TCCR1A = (1 << WGM12) | (1 << WGM10); //Fast PWM 8-Bit
    TCCR1B = (1 << CS12)  | (1 << CS10); //PRESCALE clk/1024
    
    // set Timer1 OC1A/B
    TCCR2A = (1 << WGM21) | (1 << WGM20); //Fast PWM
    TCCR2B = (1 << CS22) | (1 << CS21) | (1 << CS20); //PRESCALE clk/1024
    
    /*
    TCCR2A |= (1 << COM2A1); //Enable PWM OC2A
    TCCR2A &= ~(1 << COM2A1); //Disable PWM OC2A
    
    TCCR0A |= (1 << COM0A1); //Enable PWM OC0A
    TCCR0A &= ~(1 << COM0A1); //Disable PWM OC0A
    TCCR0A |= (1 << COM0B1); //Enable PWM OC0B
    TCCR0A &= ~(1 << COM0B1); //Disable PWM OC0B
    
    TCCR1A |= (1 << COM1A1); //Enable PWM OC1A
    TCCR1A &= ~(1 << COM1A1); //Disable PWM OC1A
    TCCR1A |= (1 << COM1B1); //Enable PWM OC1B
    TCCR1A &= ~(1 << COM1B1); //Disable PWM OC1B
    */

}

void rotiere_A_zu_Position(int Position){
    TCCR0A |= (1 << COM0A1); //Enable PWM OC0A
    
    if (Position >270) {
    Position = 270;
    } else if (Position <0) {
    Position = 0;
    }
    
    OCR0A = (uint8_t)(((Position/270)*30)+7);
}

void rotiere_B_zu_Position(int Position){
    TCCR0A |= (1 << COM0B1); //Enable PWM OC0B
    
    if (Position >270) {
    Position = 270;
    } else if (Position <0) {
    Position = 0;
    }
    
    OCR0B = (uint8_t)(((Position/270)*30)+7);
}

void rotiere_C_zu_Position(int Position){
    TCCR2A |= (1 << COM2A1); //Enable PWM OC2A
    
    if (Position >270) {
    Position = 270;
    } else if (Position <0) {
    Position = 0;
    }
    
    OCR2A = (uint8_t)(((Position/270)*30)+7);
}

void rotiere_D(int Geschwindigkeit){
    TCCR1A |= (1 << COM1A1); //Enable PWM OC1A

    if (Geschwindigkeit>100) {
    Geschwindigkeit = 100;
    } else if (Geschwindigkeit<-100) {
    Geschwindigkeit = -100;
    }
    
    OCR1A = (uint8_t)((((Geschwindigkeit+100)/200)*30)+7);
}

void rotiere_E(int Geschwindigkeit){
    TCCR1A |= (1 << COM1B1); //Enable PWM OC1B

    if (Geschwindigkeit>100) {
    Geschwindigkeit = 100;
    } else if (Geschwindigkeit<-100) {
    Geschwindigkeit = -100;
    }
    
    OCR1B = (uint8_t)((((Geschwindigkeit+100)/200)*30)+7);
}

void stoppe_D(){
    TCCR1A &= ~(1 << COM1A1); //Disable PWM OC1A
}

void stoppe_E(){
    TCCR1A &= ~(1 << COM1B1); //Disable PWM OC1B
}

bool ist_1_gedrueckt(){
  return analogRead(INPUT_1) < 512;
}

bool ist_2_gedrueckt(){
  return analogRead(INPUT_2) < 512;
}

bool ist_3_gedrueckt(){
  return analogRead(INPUT_3) < 512;
}

bool ist_Knopf_gedrueckt(){
  return digitalRead(BUTTON) == LOW;
}

int distanz_A(){
    digitalWrite(ULTRA_TRIG,LOW);
    delayMicroseconds(2);
    digitalWrite(ULTRA_TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(ULTRA_TRIG, LOW);
    unsigned long duration = pulseIn(ULTRA_REC_A, HIGH);
    int distance = (int) duration * 0.034 / 2;
    if (distance <=200){
    return distance;
    }
    return 200;
}

int distanz_B(){
    digitalWrite(ULTRA_TRIG,LOW);
    delayMicroseconds(2);
    digitalWrite(ULTRA_TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(ULTRA_TRIG, LOW);
    unsigned long duration = pulseIn(ULTRA_REC_B, HIGH);
    int distance = (int) duration * 0.034 / 2;
    if (distance <=200){
        return distance;
    }
    return 200;
}

void schalte_LED1_an() {
  digitalWrite(LED_1,HIGH);
}

void schalte_LED1_aus() {
  digitalWrite(LED_1,LOW);
}

void schalte_LED2_an() {
  digitalWrite(LED_2,HIGH);
}

void schalte_LED2_aus() {
  digitalWrite(LED_2,LOW);
}

void warte(double Sekunden){
    int time_ms = Sekunden*1000;
    for (int i = 0; i < time_ms; i++){
        _delay_ms(1);
    }
}
